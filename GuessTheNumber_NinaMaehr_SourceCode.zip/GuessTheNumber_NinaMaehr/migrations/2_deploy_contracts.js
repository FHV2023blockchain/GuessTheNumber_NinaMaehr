const GuessTheNumber = artifacts.require("./GuessTheNumber.sol")

module.exports = function(deployer) {
	deployer.deploy(GuessTheNumber);
};